gsap.registerPlugin(ScrollTrigger);
gsap.registerPlugin(MotionPathPlugin);


document.addEventListener("DOMContentLoaded", function () {
  showPopup();
});

function showPopup() {
  var popupContainer = document.querySelector(".popup-container");
  popupContainer.style.display = "flex";
}

function closePopup() {
  var popupContainer = document.querySelector(".popup-container");
  popupContainer.style.display = "none";
}



document.addEventListener('DOMContentLoaded', function() {
  AOS.init();
});

/*      #1 - LE PUIT     */


// Fonction pour obtenir la résolution de l'écran
function getResolution() {
  return {
    width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
  };
}

function createAnimation(selector, yValueLarge, yValueSmall, startPercentage = "20% top") {
  // Obtenir la résolution actuelle
  const resolution = getResolution();

  // Définir la valeur de y en fonction de la résolution
  let yValue = (resolution.width >= 1710) ? yValueLarge : yValueSmall;

  gsap.to(selector, {
    duration: 1.5,
    y: yValue,
    scrollTrigger: {
      trigger: '.puit',
      start: startPercentage,
      
    },
  });
}

// Utilisation de la fonction pour créer des animations avec des valeurs spécifiques
createAnimation(".puit__pompe", -420, -420, "top top");
createAnimation(".puit__coton", -67, -68, "top top");
createAnimation(".puit__arbres", -445, -385, "top top");
createAnimation(".puit__mais", -236, -200, "40% top");
createAnimation(".puit__soja", -80, -60, "60% top");
createAnimation(".puit__bambou", -346, -300, "80% top");



/*      #2 - LES ANIMAUX     */

function createAnimalAnimation(selector, yValueAnimalL, yValueAnimalS, startPercentageL, startPercentageS, loopOffset) {
  let resolution = getResolution();
  let animal = document.querySelector(selector);
  let yValueAnimal = (resolution.width >= 1710) ? yValueAnimalL : yValueAnimalS;
  let startPercentage = (resolution.width >= 1710) ? startPercentageL : startPercentageS;

  gsap.to(animal, {
    duration: 1.5,
    y: yValueAnimal, 
    scrollTrigger: {
      trigger: '.puit',
      start: `${startPercentage}% top`,
      
      onEnter: () => {
        animal.play();
        animal.setAttribute('loop', '');
      },
      onLeaveBack: () => {
        animal.removeAttribute('loop', '');
      },
    },
  });
}

createAnimalAnimation(".champ__vache", -220, -350, 100, 120, 0);
createAnimalAnimation(".champ__mouton", -150, -300, 120, 160, 0);
createAnimalAnimation(".champ__chevre", -150, -280, 140, 200, 0);
createAnimalAnimation(".champ__alpaga", -290, -290, 160, 240, 0);
createAnimalAnimation(".champ__lapin", -98, -240, 180, 280, 0);


/*      #3 - LE TRAJET DU CAMION     */

// Animation du camion
let camion = gsap.to(".trajet__camion", {
  duration: 5,
  x: document.querySelector('.trajet').clientWidth - 500,
  ease: "power1.out",
  paused: true, // L'animation est initialement en pause
});

gsap.to(".trajet", {
  scrollTrigger: {
    trigger: '.trajet',
    start: "350% top",
    onEnter: () => camion.play(), // Déclenche l'animation lorsque le point de départ est atteint
    onLeaveBack: () => camion.reverse(), // Inverse l'animation lorsque l'on remonte
    scrub: 2,
  },
});


// Fonction pour créer un tween de cloud
function createCloudTween(cloudSelector) {
  let clouds = gsap.to(cloudSelector, {
    duration: 20,
    x: document.querySelector('.trajet').clientWidth - 500,
    ease: "power1.out",
    paused: true,
  });

  gsap.to(cloudSelector, {
    scrollTrigger: {
      trigger: '.trajet',
      start: "400% top",
      onEnter: () => clouds.play(),
      onLeaveBack: () => clouds.reverse(),
      
      scrub: 2,
    },
  });
}

createCloudTween(".trajet__nuage");
createCloudTween(".trajet__nuage2");
createCloudTween(".trajet__nuage3");





/*      #4 - DANS L'USINE     */

let couture = document.querySelector(".usine__couture-machine");
let couturepersonne = document.querySelector(".usine__couture-personne");
gsap.to(couture, {
  scrollTrigger: {
    trigger: '.puit',
    start: "630% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(couture, { opacity: 1, duration: 1 });
      gsap.to(couturepersonne, { opacity: 1, duration: 1 });
      couture.play();
      couture.setAttribute('loop', '');
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(couture, { opacity: 0, duration: 0.5 });
      gsap.to(couturepersonne, { opacity: 0, duration: 0.5 });
      couture.removeAttribute('loop','');
    },
  },
});



let fusain = document.querySelector(".usine__fusain-machine");
let fusainpersonne = document.querySelector(".usine__fusain-personne");
gsap.to(fusain, {
  scrollTrigger: {
    trigger: '.puit',
    start: "700% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(fusain, { opacity: 1, duration: 1 });
      gsap.to(fusainpersonne, { opacity: 1, duration: 1 });
      couture.play();
      couture.setAttribute('loop', '');
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(fusain, { opacity: 0, duration: 0.5 });
      gsap.to(fusainpersonne, { opacity: 0, duration: 0.5 });
      couture.removeAttribute('loop','');
    },
  },
});


let carton = document.querySelector(".usine__carton-machine");
gsap.to(carton, {
  scrollTrigger: {
    trigger: '.puit',
    start: "770% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(carton, { opacity: 1, duration: 1 });
      couture.play();
      couture.setAttribute('loop', '');
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(carton, { opacity: 0, duration: 0.5 });
      couture.removeAttribute('loop','');
    },
  },
});





let baril = document.querySelector(".accident__baril");
gsap.to(baril, {
  scrollTrigger: {
    trigger: '.puit',
    start: "850% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(baril, { opacity: 1, duration: 1 });
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(baril, { opacity: 0, duration: 0.5 });
    },
  },
});

let colorant = document.querySelector(".accident__colorant-machine");
let colorantpersonne = document.querySelector(".accident__colorant-personne");
gsap.to(colorant, {
  scrollTrigger: {
    trigger: '.puit',
    start: "910% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(colorant, { opacity: 1, duration: 1 });
      gsap.to(colorantpersonne, { opacity: 1, duration: 1 });
      colorant.play();
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(colorant, { opacity: 0, duration: 0.5 });
      gsap.to(colorantpersonne, { opacity: 0, duration: 0.5});
    },
  },
});


let feu = document.querySelector(".accident__feu-flamme");
let feupersonne = document.querySelector(".accident__feu-personne");
gsap.to(feu, {
  scrollTrigger: {
    trigger: '.puit',
    start: "980% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(feu, { opacity: 1, duration: 1 });
      gsap.to(feupersonne, { opacity: 1, duration: 1 });
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(feu, { opacity: 0, duration: 0.5 });
      gsap.to(feupersonne, { opacity: 0, duration: 0.5});
    },
  },
});


let madagascar = document.querySelector(".salaire__madagascar");
gsap.to(madagascar, {
  scrollTrigger: {
    trigger: '.puit',
    start: "1050% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(madagascar, { opacity: 1, duration: 1 });
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(madagascar, { opacity: 0, duration: 0.5 });
    },
  },
});


let inde = document.querySelector(".salaire__inde");
gsap.to(inde, {
  scrollTrigger: {
    trigger: '.puit',
    start: "1100% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(inde, { opacity: 1, duration: 1 });
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(inde, { opacity: 0, duration: 0.5 });
    },
  },
});


let chine = document.querySelector(".salaire__chine");
gsap.to(chine, {
  scrollTrigger: {
    trigger: '.puit',
    start: "1150% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(chine, { opacity: 1, duration: 1 });
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(chine, { opacity: 0, duration: 0.5 });
    },
  },
});


/*  SORTIE DE L'USINE   */

gsap.to(".sortie__bateau", {
  duration: 6,
  x: 1190,
  scrollTrigger: {
    trigger: '.puit',
    start: "1380% top",
    
  },
});

// Animation de l'avion en suivant un SVG crée

let avion = document.querySelector(".sortie__avion");
let avion__path = document.querySelector(".sortie__path");

// lancement de l'animation
gsap.to(avion, {
  opacity: 1,
  duration: 3,
  ease: "none",
  // définir le lancement
  scrollTrigger: {
    trigger: '.puit',
    start: "1330% top",
    
  },
  // déinir un mouvement le long d'un chemin spécifique (<path>)
  motionPath: {
    path: avion__path,
    align: avion__path,
    alignOrigin: [0.5, 0.5],// cette propriété aligne l'élément avec le chemin spécifique
    autoRotate: false, // activer ou désactiver la rotation automatique de l'élément
  }
});




/*  LE GLOBE   */

// Animation de l'avion en suivant un SVG crée

let bateau = document.querySelector(".globe__bateau");
let path = document.querySelector(".globe__path");

// lancement de l'animation
gsap.to(bateau, {
  opacity: 1,
  duration: 5,
  ease: "none",
  // définir le lancement
  scrollTrigger: {
    trigger: '.puit',
    start: "1450% top",
    
  },
  // déinir un mouvement le long d'un chemin spécifique (<path>)
  motionPath: {
    path: path,
    align: path,
    alignOrigin: [0.3, 0.3],// cette propriété aligne l'élément avec le chemin spécifique
    autoRotate: true, // activer ou désactiver la rotation automatique de l'élément
  }
});


let stats = document.querySelector(".globe__stat");
gsap.to(stats, {
  scrollTrigger: {
    trigger: '.puit',
    start: "1500% top",
    onEnter: () => {
      // Lorsque l'élément entre dans la vue, anime l'opacité à 1
      gsap.to(stats, { opacity: 1, duration: 1 });
    },
    onLeaveBack: () => {
      // Lorsque l'utilisateur fait défiler vers l'arrière, réinitialise l'opacité à 0
      gsap.to(stats, { opacity: 0, duration: 0.5 });
    },
  },
});




/*  AU SEIN DE LA VILLE   */

function getResolution() {
  return {
    width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
    // height: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
  };
}

function createAnimation(selector, yValueLarge, yValueSmall, startPercentage = "20% top") {
  // Obtenir la résolution actuelle
  const resolution = getResolution();

  // Définir la valeur de y en fonction de la résolution
  let yValue = (resolution.width >= 1710) ? yValueLarge : yValueSmall;

  gsap.to(selector, {
    duration: 1.5,
    y: yValue,
    scrollTrigger: {
      trigger: '.puit',
      start: startPercentage,
      
    },
  });
}

// Utilisation de la fonction pour créer des animations avec des valeurs spécifiques
createAnimation(".ville__list-panneau1", -400, -600, "1600% top");
createAnimation(".ville__list-panneau2", -400, -600, "1650% top");
createAnimation(".ville__list-panneau3", -400, -600, "1700% top");










/* TOUTES LES PRÉVISUALISATIONS DE DATA */


function initLottieAnimation(containerSelector, path, loop, autoplay) {
  const animation = lottie.loadAnimation({
    container: document.querySelector(containerSelector),
    renderer: 'svg',
    loop: loop,
    autoplay: autoplay,
    path: path,
  });

  // Configurez l'animation pour jouer seulement pendant la moitié de la durée
  animation.goToAndStop(0, true);

  // Ajoutez un gestionnaire d'événement pour jouer la suite au survol
  document.querySelector(containerSelector).addEventListener('mouseenter', () => {
    animation.playSegments([0, animation.totalFrames], true);
  });

  // Ajoutez un gestionnaire d'événement pour revenir au début lorsque la souris quitte l'animation
  document.querySelector(containerSelector).addEventListener('mouseleave', () => {
    animation.goToAndStop(0, true);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initLottieAnimation('.puit__particule-data', 'assets/tuto_data.json', true, true);
  initLottieAnimation('.puit__pompe-data', 'assets/data_petrole.json', false, false);
  initLottieAnimation('.puit__coton-data', 'assets/data_coton.json', false, false);
  initLottieAnimation('.puit__arbres-data', 'assets/data_viscose.json', false, false);
  initLottieAnimation('.champ__laine-data', 'assets/data_laine.json', false, false);
  initLottieAnimation('.usine__enfant-data', 'assets/data_enfants_travailleurs.json', false, false);
  initLottieAnimation('.accident__baril-data', 'assets/data_barils.json', false, false);
  initLottieAnimation('.accident__feu-data', 'assets/data_incendies.json', false, false);
});



















let sections = gsap.utils.toArray(".container__panel");

gsap.to(sections, {
  xPercent: -100 * (sections.length - 1),
  ease: "none",
  scrollTrigger: {
    trigger: ".container",
    scrub: 1,
    pin: true,
    snap: false,
    end: () => "+=" + document.querySelector(".container").offsetWidth,
  }
});
